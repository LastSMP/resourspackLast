LastSMP Sound Pack

What is included:
- Light replacement of several vanilla sounds:
  - entity.player.levelup
  - entity.experience_orb.pickup
  - block.note_block.bell
- New custom sound events in namespace lastsmp:
  - lastsmp:join
  - lastsmp:crate_open
  - lastsmp:boss_warning
  - lastsmp:test_loud

How to test in game:
- /playsound lastsmp:join master @s
- /playsound lastsmp:crate_open master @s
- /playsound lastsmp:boss_warning master @s
- /playsound lastsmp:test_loud master @s

How to add your own real audio files later:
1) Put .ogg files into assets/lastsmp/sounds/custom/
2) In assets/lastsmp/sounds.json, set entries like:
   "name": "custom/your_file_without_ogg"
   (and remove "type": "event" for file-based sounds)
3) Re-zip the pack and distribute it.